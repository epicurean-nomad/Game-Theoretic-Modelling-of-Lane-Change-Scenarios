let targetX = null;
let targetY = null;

let xValues = [];

let laneUpper = 300
let laneWidth = 200;
laneLower = laneUpper+laneWidth;

let curvatureBound = 0.01;

let x0 = 100;
let y0 = laneUpper;

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}


function setup() {
  
  createCanvas(windowWidth, windowHeight);

  
  // for (let x = 0; x <= windowWidth; x += 5) {
  //   xValues.push(x);
  // }

  // console.log("length",xValues.length)
  gammaSlider = createSlider(0,1,0.5,0.01)
  gammaSlider.position(50,10)
  
  lambdaSlider = createSlider(0,1,0.5,0.01)
  lambdaSlider.position(350,10)
  
  arcLengthSlider = createSlider(0,windowWidth,100,1)
  arcLengthSlider.position(50,30)
  
  curvatureSlider = createSlider(0,0.01,0.005,0.0001)
  curvatureSlider.position(350,30)
  
  
}

function VCA(alpha_){
  p0 = 1
  p1 = 1.34 * pow(10,-4)
  p2 = -6.75 * pow(10,-2)
  p3 = 1.64 * pow(10,-3)
  
  return p0 + p1*(alpha_) + p2*(alpha_**2) + p3*(alpha_**3)
}


function mousePressed() {
  
  if(mouseY > laneUpper){
    targetX = mouseX
    targetY = mouseY
  }
  
  else{
    targetX = null
    targetY = null
  }

}



function grad(alpha_,gamma,lambda,k1,dy){
  p0 = 1
  p1 = 1.34 * pow(10,-4)
  p2 = -6.75 * pow(10,-2)
  p3 = 1.64 * pow(10,-3)
  
  f = 2*alpha_*((gamma*VCA(alpha_)*sin(alpha_/2)) + ((1-gamma)*sin(alpha_))) - (lambda*gamma*k1)*dy
  
  df = (2/(lambda*gamma*k1))*(gamma*( sin(alpha_/2)*( p0 + 2*p1*alpha_ + 3*p2*(alpha_**2) + 4*p3*(alpha_**3) ) + 0.5*cos(alpha_/2)*VCA(alpha_) ) + (1-gamma)*( sin(alpha_) + alpha_*cos(alpha_) ) )
  
  return f/df
}


function grad_desc(gamma,lambda,k1,dy){
  
  alpha_ = PI/4
  epsilon = pow(10,-6)
  
  while (true){
    f = 2*(alpha_/(lambda*gamma*k1))*(gamma*VCA(alpha_)*sin(alpha_/2) + (1-gamma)*sin(alpha_)) - dy
    if(abs(f) < epsilon){
      return alpha_
    }
    alpha_ -= grad(alpha_,gamma,lambda,k1,dy)
  }
  
}


function clothoidSineIntegral(s,k,S,psi_i,min_){
  
  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * sin( ( (k/S)*(i**2) ) + psi_i)
  }
  return ans
}

function clothoidCosIntegral(s,k,S,psi_i,min_){
  
  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * cos( ( (k/S)*(i**2) ) + psi_i)
  }
  return ans
}

function clothoidSineIntegral2(s,k1,S1,psi_i,min_){

  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * sin((0.67*(k1/S1)*i*(S1-(i/2))) + psi_i)
  }
  return ans
}

function clothoidCosIntegral2(s,k1,S1,psi_i,min_){
  // min = S1/2;
  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * cos((0.67*(k1/S1)*i*(S1-(i/2))) + psi_i)
  }
  return ans
}



function draw() {
  background(220);
  console.log(windowWidth)
  text('Gamma : (S1+S2)/S', gammaSlider.x + gammaSlider.width + 5, 25);
  text('Lambda : S1/(S1+S2)', lambdaSlider.x + lambdaSlider.width + 5, 25);
  text('S : ArcLength', arcLengthSlider.x + arcLengthSlider.width + 5, 45);
  text('k1 : Curvature of S1', curvatureSlider.x + arcLengthSlider.width + 5, 45);
  fill('white')
  lane = rect(0,laneUpper,windowWidth,laneWidth)
  fill('red')
  car = circle(x0,y0,10)

  
  
  
  gamma = gammaSlider.value();
  // lambda = 0.5;
  lambda = lambdaSlider.value()
  
  
  // arcLength = windowWidth/2
  
  
  k1 = curvatureSlider.value()
  
  arcLength = arcLengthSlider.value();
  alpha_ =  lambda*gamma*arcLength*k1*0.5;
  
  
  
  if(targetX != null && targetY != null){
    
    dY = targetY - laneUpper;
    alpha_ = grad_desc(gamma,lambda,k1,dY)
    arcLength = 2*alpha_/(lambda*gamma*k1)
    
    fill('black')
    circle(targetX,targetY,10)
    
    // f = 2*(alpha_/(lambda*gamma*k1))*(gamma*VCA(alpha_)*sin(alpha_/2) + (1-gamma)*sin(alpha_))
  
    // console.log("f = ",f+laneUpper)
    // console.log("target Y = ", targetY)
  }
  
  
  S1 = lambda*gamma*arcLength;
  S2 = (1-lambda)*gamma*arcLength;
  L = (1-gamma)*arcLength
  
  
  k2 = -k1*(S1/S2)
  
  // console.log("predicted alpha = ",alpha_)
  // console.log("plotted alpha = ",k1*S1/2)
  // console.log("targetX = ",targetX)
  // console.log("targetY = ",targetY)
  // console.log("k1 = ",k1)
  // console.log("k2 = ",k2)
  
  // console.log("S1 = ",S1)
  // console.log("S2 = ",S2)

  psi_i = 0
  psi_f1 = k1*S1/4
  psi_f2 = k1*S1/2
  psi_f3 = k1*S1/4
  
  yf1 = clothoidSineIntegral(S1/2,k1,S1,psi_i,0) + y0;
  xf1 = clothoidCosIntegral(S1/2,k1,S1,psi_i,0) + x0;
  
  yf2 = clothoidSineIntegral2(S1,k1,S1,psi_f1,S1/2) + yf1;
  xf2 = clothoidCosIntegral2(S1,k1,S1,psi_f1,S1/2) + xf1;
  
  yf3 = (arcLength-(S2)-S1)*sin(psi_f2) + yf2
  xf3 = (arcLength-(S2)-S1)*cos(psi_f2) + xf2
  
  yf4 = clothoidSineIntegral(arcLength-(S2/2),k2,S2,psi_f2,S1+L) + yf3;
  xf4 = clothoidCosIntegral(arcLength-(S2/2),k2,S2,psi_f2,S1+L) + xf3;
  
  
  for(s=1;s<=arcLength;s+=1){
    if(s<=S1/2){
    x = x0
    y = y0
    
    y += clothoidSineIntegral(s,k1,S1,psi_i,0);
    x += clothoidCosIntegral(s,k1,S1,psi_i,0);

    
    fill('green')
    circle(x,y,2)
    // console.log("x = ",x)
    // console.log("y = ",y)
    }
    
    else if(s<=S1){
      // if(s<=S1){
      x = xf1
      y = yf1
    
      y += clothoidSineIntegral2(s,k1,S1,psi_f1,S1/2);
      x += clothoidCosIntegral2(s,k1,S1,psi_f1,S1/2);

    
      fill('green')
      circle(x,y,2)
    }
    
    else if(s<=S1+L){
      x = xf2
      y = yf2
    
      y += (s-S1)*sin(psi_f2)
      x += (s-S1)*cos(psi_f2)

    
    fill('red')
    circle(x,y,2)
    }
    else if(s<=arcLength-(S2/2)){
      x = xf3
      y = yf3
    
      y += clothoidSineIntegral(s,k2,S2,psi_f2,S1+L);
      x += clothoidCosIntegral(s,k2,S2,psi_f2,S1+L);


    
    fill('blue')
    circle(x,y,2)
    }
    else{
      x = xf4
      y = yf4
    
      y += clothoidSineIntegral2(s,k2,S2,psi_f3,arcLength-(S2/2));
      x += clothoidCosIntegral2(s,k2,S2,psi_f3,arcLength-(S2/2));
      
      fill('blue')
      circle(x,y,2)
    }
  }
}