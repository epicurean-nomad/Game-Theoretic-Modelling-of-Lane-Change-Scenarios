class Car2 {
  
  
  constructor(xlim, v0, a) {


    this.vel = v0
    this.acc = a
    this.xlim = xlim
    this.pos = {'s':0,'x': 100,'y': laneUpper}
    this.r = 10;
    // this.k = this.traj.k
    this.coll = false
    this.vmax = 60
    this.reward = 0
    this.totalReturn = 0
    this.time_counter = 0
    this.fin = false
    this.episodeCounter = 0
  }

  reward_update(){
    if(this.coll == false){
      // console.log("Logging Return: ",(this.vel/this.vmax))
      this.reward += (this.vel/this.vmax)
    } 
  }

  update() {
  

    if(this.pos.x < this.xlim + 40 && this.coll == false){ 
  
      this.pos.x += this.vel
      this.vel += this.acc
    
      fill('turquoise')
      circle(this.pos.x,this.pos.y,this.r)
      this.time_counter += 1
      
      this.reward_update()
    } 
    
    else{
      // console.log("Im Here!!")
      if(this.fin == false){
        this.reward = (this.reward)/this.time_counter 
        this.fin = true
      } 
    }
 
}
  
  
  
  collision(){
    this.coll = true
    this.fin = true
    console.log("COLLISION!")
    this.reward += -4*(abs(this.xlim - x0))
  }
  
  reset(xlim,v){
    
    // console.log("Time taken: ",this.time_counter)
    this.episodeCounter += 1
    this.totalReturn = ((this.episodeCounter-1)*this.totalReturn/this.episodeCounter) + (this.reward/this.episodeCounter)
    
    // console.log(traject)
    this.pos = {'s':0,'x': 100,'y': laneUpper}
    this.vel = v
    this.xlim = xlim
    // this.k = this.traj.k
    // console.log(this.traj)
    this.time_counter = 0
    this.coll = false
    this.fin = false
    this.reward = 0
    return this.totalReturn
    
  }

}