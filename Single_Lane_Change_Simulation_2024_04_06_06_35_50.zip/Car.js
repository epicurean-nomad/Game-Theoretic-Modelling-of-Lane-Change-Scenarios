class Car {
  
  
  constructor(traj, v0, a) {


    this.vel = v0
    this.acc = a
    this.traj = traj
    this.pos = {'s':0,'x': this.traj.startX,'y': this.traj.startY}
    this.r = 10;
    this.k = this.traj.k
    this.coll = false
    this.vmax = 60
    this.reward = 0
    this.totalReturn = 0
    this.time_counter = 0
    this.fin = false
    this.episodeCounter = 0
  }

  reward_update(){
    if(this.coll == false){
      // console.log("Logging Return: ",(this.vel/this.vmax))
      this.reward += (this.vel/this.vmax)
    } 
  }

  update() {
  
  // if(this.laneChange == true){
      
      S1 = this.traj.S1
      S2 = this.traj.S2
      L = this.traj.L
  // k = this.k
  
  // console.log(S1)
  // console.log(S2)
  // console.log(L)
  // console.log(this.k)
  

  k2 = -(this.k)*(S1/S2)
  arcLength = abs(S1+S2+L)
  // k1_ = this.k*1
  // s = this.pos
  
  // console.log("s = ",s)
  // console.log("S1/2 = ",S1/2)
  
  
  psi_i = 0
  psi_f1 = this.k*S1/4
  psi_f2 = this.k*S1/2
  psi_f3 = this.k*S1/4
  
  
  yf1 = clothoidSineIntegral(S1/2,this.k,S1,psi_i,0) + this.traj.startY;
  xf1 = clothoidCosIntegral(S1/2,this.k,S1,psi_i,0) + this.traj.startX;

  
    
  // console.log("this.pos = ",this.pos)
  // console.log("xf1 = ",xf1)
  yf2 = clothoidSineIntegral2(S1,this.k,S1,psi_f1,S1/2) + yf1;
  xf2 = clothoidCosIntegral2(S1,this.k,S1,psi_f1,S1/2) + xf1;
  
  yf3 = (arcLength-(S2)-S1)*sin(psi_f2) + yf2
  xf3 = (arcLength-(S2)-S1)*cos(psi_f2) + xf2
  
  yf4 = clothoidSineIntegral(arcLength-(S2/2),k2,S2,psi_f2,S1+L) + yf3;
  xf4 = clothoidCosIntegral(arcLength-(S2/2),k2,S2,psi_f2,S1+L) + xf3;
  
  // xfin = clothoidCosIntegral2(arcLength,k2,S2,psi_f3,arcLength-(S2/2)) + xf4;
  
  
  
if(this.pos.s < arcLength && this.coll == false){ 
  
  this.pos.s += this.vel
  this.vel += this.acc
    
  if(this.pos.s<=S1/2){
    x = this.traj.startX
    y = this.traj.startY
    
    y += clothoidSineIntegral(this.pos.s,this.k,S1,psi_i,0);
    x += clothoidCosIntegral(this.pos.s,this.k,S1,psi_i,0);


    }
    
    else if(this.pos.s<=S1){
      // if(s<=S1){
      x = xf1
      y = yf1
    
      y += clothoidSineIntegral2(this.pos.s,this.k,S1,psi_f1,S1/2);
      x += clothoidCosIntegral2(this.pos.s,this.k,S1,psi_f1,S1/2);

      
    }
    
    else if(this.pos.s<=S1+L){
      x = xf2
      y = yf2
    
      y += (this.pos.s-S1)*sin(psi_f2)
      x += (this.pos.s-S1)*cos(psi_f2)
    
    
    
    }
    else if(this.pos.s<=arcLength-(S2/2)){
      x = xf3
      y = yf3
    
      y += clothoidSineIntegral(this.pos.s,k2,S2,psi_f2,S1+L);
      x += clothoidCosIntegral(this.pos.s,k2,S2,psi_f2,S1+L);


    
    }
    else{
      x = xf4
      y = yf4
    
      y += clothoidSineIntegral2(this.pos.s,k2,S2,psi_f3,arcLength-(S2/2));
      x += clothoidCosIntegral2(this.pos.s,k2,S2,psi_f3,arcLength-(S2/2));
      
      
    }
      fill('turquoise')
      circle(x,y,this.r)
      this.time_counter += 1
      this.pos.x = x
      this.pos.y = y
      
      this.reward_update()
    } 
    
    else{
      // console.log("Im Here!!")
      if(this.fin == false){
        this.reward = (this.reward)/this.time_counter 
        this.fin = true
      } 
    }
  
   
  
 
}
  
  
  
  collision(){
    this.coll = true
    this.fin = true
    console.log("COLLISION!")
    this.reward += -4*(abs(this.traj.S1 + this.traj.S2 + this.traj.L))
  }
  
  reset(traject,v){
    
    // console.log("Time taken: ",this.time_counter)
    this.episodeCounter += 1
    this.totalReturn = ((this.episodeCounter-1)*this.totalReturn/this.episodeCounter) + (this.reward/this.episodeCounter)
    
    // console.log(traject)
    this.pos = {'s':0,'x': this.traj.startX,'y': this.traj.startY}
    this.vel = v
    this.traj = traject
    this.k = this.traj.k
    // console.log(this.traj)
    this.time_counter = 0
    this.coll = false
    this.fin = false
    this.reward = 0
    return this.totalReturn
    
  }

}