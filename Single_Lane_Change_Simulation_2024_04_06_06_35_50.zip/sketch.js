let targetX = null;
let targetY = null;

let N = 1000;

let xmax;


let laneUpper = 300
let laneWidth = 200;
laneLower = laneUpper+laneWidth;

let curvatureBound = 0.01;

let x0 = 100;
let y0 = laneUpper;
let y1 = laneLower;


// let trajectory_a = [];
// let trajectory_b = [];
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}





function VCA(alpha_){
  p0 = 1
  p1 = 1.34 * pow(10,-4)
  p2 = -6.75 * pow(10,-2)
  p3 = 1.64 * pow(10,-3)
  
  return p0 + p1*(alpha_) + p2*(alpha_**2) + p3*(alpha_**3)
}



function grad(alpha_,gamma,lambda,k1,dy){
  p0 = 1
  p1 = 1.34 * pow(10,-4)
  p2 = -6.75 * pow(10,-2)
  p3 = 1.64 * pow(10,-3)
  
  f = 2*(alpha_/(lambda*gamma*k1))*(gamma*VCA(alpha_)*sin(alpha_/2) + (1-gamma)*sin(alpha_)) - dy
  
  df = (2/(lambda*gamma*k1))*(gamma*( sin(alpha_/2)*( p0 + 2*p1*alpha_ + 3*p2*(alpha_**2) + 4*p3*(alpha_**3) ) + 0.5*cos(alpha_/2)*VCA(alpha_) ) + (1-gamma)*( sin(alpha_) + alpha_*cos(alpha_) ) )
  
  return f/df
}


function grad_desc(gamma,lambda,k1,dy){
  
  alpha_ = PI/4
  epsilon = pow(10,-6)
  
  while (true){
    f = 2*(alpha_/(lambda*gamma*k1))*(gamma*VCA(alpha_)*sin(alpha_/2) + (1-gamma)*sin(alpha_)) - dy
    if(abs(f) < epsilon){
      return alpha_
    }
    alpha_ -= grad(alpha_,gamma,lambda,k1,dy)
  }
  
}


function clothoidSineIntegral(s,k,S,psi_i,min_){
  

  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * sin( ( (k/S)*(i**2) ) + psi_i)
  }
  return ans
}

function clothoidCosIntegral(s,k,S,psi_i,min_){
  

  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * cos( ( (k/S)*(i**2) ) + psi_i)
  }
  return ans
}

function clothoidSineIntegral2(s,k1,S1,psi_i,min_){
  

  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * sin(0.67*(k1/S1)*i*(S1-(i/2)) + psi_i)
    // ans += ((s-min_)/numPoints) * sin(0.5*(k1/S1)*i*(S1-(i/2)) + psi_i)
  }
  return ans
}

function clothoidCosIntegral2(s,k1,S1,psi_i,min_){
  // min = S1/2;

  numPoints = 100;
  ans=0
  for(i=0;i<=s-min_;i+=(s-min_)/numPoints){
    ans += ((s-min_)/numPoints) * cos(0.67*(k1/S1)*i*(S1-(i/2)) + psi_i)
    // ans += ((s-min_)/numPoints) * cos(0.5*(k1/S1)*i*(S1-(i/2)) + psi_i)
  }
  return ans
}


function plotStraight(xlim,x_init,y_init){
  line(x_init,y_init,xlim,y_init)
}

function plot(gamma,lambda,k1,dY,x_init,y_init){
  
  alpha_ = grad_desc(gamma,lambda,abs(k1),dY)*(k1/abs(k1))
  arcLength = abs(2*alpha_/(lambda*gamma*k1))

  
  S1 = abs(lambda*gamma*arcLength);
  S2 = abs((1-lambda)*gamma*arcLength);
  L = abs((1-gamma)*arcLength)
  
  
  k2 = -k1*(S1/S2)
  
  trajectory = []
  traj = {'startX':x_init,'startY':y_init,'S1':S1,'S2':S2,'k':k1,'L':L}
  append(trajectory,[x0,y0,0])
  
  
  psi_i = 0
  psi_f1 = k1*S1/4
  // psi_f2 = k1*S1/2
  psi_f2 = alpha_
  psi_f3 = k1*S1/4
  
  // console.log("alpha = ",alpha_)
  
  yf1 = clothoidSineIntegral(S1/2,k1,S1,psi_i,0) + y_init;
  xf1 = clothoidCosIntegral(S1/2,k1,S1,psi_i,0) + x_init;
  
  yf2 = clothoidSineIntegral2(S1,k1,S1,psi_f1,S1/2) + yf1;
  xf2 = clothoidCosIntegral2(S1,k1,S1,psi_f1,S1/2) + xf1;
  
  yf3 = (arcLength-(S2)-S1)*sin(psi_f2) + yf2
  xf3 = (arcLength-(S2)-S1)*cos(psi_f2) + xf2
  
  yf4 = clothoidSineIntegral(arcLength-(S2/2),k2,S2,psi_f2,S1+L) + yf3;
  xf4 = clothoidCosIntegral(arcLength-(S2/2),k2,S2,psi_f2,S1+L) + xf3;
  
  xfin = clothoidCosIntegral2(arcLength,k2,S2,psi_f3,arcLength-(S2/2)) + xf4;
  
  
  
  for(s=1;s<=arcLength;s+=1){
    if(s<=S1/2){
    x = x_init
    y = y_init
    
    y += clothoidSineIntegral(s,k1,S1,psi_i,0);
    x += clothoidCosIntegral(s,k1,S1,psi_i,0);
    
    psi = psi_i + (k1/S1)*(s**2)
    append(trajectory,[x,y,psi])
      
    fill('turquoise')
    circle(x,y,1)

    }
    
    else if(s<=S1){
      // if(s<=S1){
      x = xf1
      y = yf1
    
      y += clothoidSineIntegral2(s,k1,S1,psi_f1,S1/2);
      x += clothoidCosIntegral2(s,k1,S1,psi_f1,S1/2);
      
      psi = psi_f1 + 0.67*(k1/S1)*s*(S1-(s/2))
      append(trajectory,[x,y,psi])
      
      fill('turquoise')
      circle(x,y,1)
    }
    
    else if(s<=S1+L){
      x = xf2
      y = yf2
    
      y += (s-S1)*sin(psi_f2)
      x += (s-S1)*cos(psi_f2)
      psi = psi_f2
    append(trajectory,[x,y,psi_f2])
      
    fill('turquoise')
    circle(x,y,1)
    }
    else if(s<=arcLength-(S2/2)){
      x = xf3
      y = yf3
    
      y += clothoidSineIntegral(s,k2,S2,psi_f2,S1+L);
      x += clothoidCosIntegral(s,k2,S2,psi_f2,S1+L);
      
      psi = psi_f2 + (k2/S2)*(s**2)
      append(trajectory,[x,y,psi])

      
    fill('turquoise')
    circle(x,y,1)
    }
    else{
      x = xf4
      y = yf4
    
      y += clothoidSineIntegral2(s,k2,S2,psi_f3,arcLength-(S2/2));
      x += clothoidCosIntegral2(s,k2,S2,psi_f3,arcLength-(S2/2));
      
      psi = psi_f3 + 0.67*(k2/S2)*s*(S2-(s/2))
      append(trajectory,[x,y,psi])
      
      
      fill('turquoise')
      circle(x,y,1)
    }

  }
  return [traj,trajectory,xfin]
}



function maxcurv(v,a){
  // return abs(sqrt((0.82*9.8)**2 - (a**2)))/v**2
  return abs(sqrt((0.82*9.8)**2 - (0.25)**2))/v**2
}

function plotTraj(trajectory){
  for(i=0;i<trajectory.length;i++){
    fill('turquoise')
    circle(trajectory[i][0],trajectory[i][1],1)
  }
}



function collisionOrEnd(car1,car2){
  
  d = dist(car1.pos.x,car1.pos.y,car2.pos.x,car2.pos.y)
  arcLength1 = abs(car1.xlim-x0)
  arcLength2 = abs(car2.traj.S1 + car2.traj.S2 + car2.traj.L)
  
  if(abs(d) < abs(car1.r/2 + car2.r/2)){
    car1.collision()
    car2.collision()
    
  }
  //CHANGE HERE
  if(car1.fin == true && car2.fin == true){
    reset_()
  }
  
  
}



function reset_(){
  
  
  vel1 = random(3,60)
  vel2 = random(3,60)
  acceleration = 0.25
  

  // gamma2 = random(0.01,0.99)
  // lambda2 = random(0.25,0.75)
  
  // gamma1 = 0.5
  // lambda1 = 0.5
  gamma2 = 0.5
  lambda2 = 0.5
  

  kmax2 = min(maxcurv(vel2,0),0.015)
  kmin = 0.0025
  dY = 200;
  
  
  
  
  traj_b_trajectory_b = plot(gamma2,lambda2,-(kmax2+kmin)/2,dY,x0,y1)
  traj_b = traj_b_trajectory_b[0]
  trajectory_b = traj_b_trajectory_b[1]
  xlim_a = traj_b_trajectory_b[2]
  
  console.log("Time taken by Car1: ", car1.time_counter)
  console.log("Time taken by Car2: ", car2.time_counter)
  rew1 = car1.reset(xlim_a,vel1)
  rew2 = car2.reset(traj_b,vel2)
    
    
    console.log("Reward for Car1: ", rew1)
    
    console.log("Reward for Car2: ", rew2)
}

function setup() {
  
  createCanvas(windowWidth, windowHeight);

  
  gamma = 0.5
  lambda = 0.5

  velocity = 5
  acceleration = 0.25
  
  
  dY = 200;
  

  
  kmax = min(maxcurv(velocity),0.015)
  kmin = 0.0025
  // kstep = 0.0005
  
  fill('white')
  lane = rect(0,laneUpper,windowWidth,laneWidth)
  fill('red')
  
  
  
  
  traj_b_trajectory_b = plot(gamma,lambda,-(kmax+kmin)/2,dY,x0,y1)
  traj_b = traj_b_trajectory_b[0]
  trajectory_b = traj_b_trajectory_b[1]
  xlim_a = traj_b_trajectory_b[2]
  
  plotStraight(x0,y0,xlim_a,y0)
  
  // console.log(traj_b)
  // console.log(trajectory_a)
  // console.log(trajectory_b)
  
  car1 = new Car2(xlim_a,velocity,acceleration)
  car2 = new Car(traj_b,velocity,acceleration)
  
}
 


function draw() {
  background(220);

  if(car2.episodeCounter > N){
    noLoop()
  }
  
  fill('white')
  lane = rect(0,laneUpper,windowWidth,laneWidth)
  
  
  plotStraight(x0,y0,xlim_a,y0)
  plotTraj(trajectory_b)
  
  collisionOrEnd(car1,car2)
  car1.update()
  car2.update()
  console.log(car1.episodeCounter)
  
}